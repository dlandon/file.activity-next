### File Activity - Next

Copyright (C) 2017-2026 Dan Landon

Permission is granted to use this software for personal, educational, or internal use only.
Commercial use, redistribution, or modification of this software or any derived works
is strictly prohibited without prior written permission.

THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.

**File Activity - Next**

This plugin displays recent read/write/modify file activity on each disk, UD disks, and the cache in the Array.  It can help to understand why disks are spinning up from write/modify file activity.

Originally developed and maintained by Dan Landon.

Project repository, documentation, and license information are available on GitHub.
<?php
/* Copyright 2026 Dan Landon
 *
 * Permission is granted to use this software for personal, educational, or internal use only.
 * Commercial use, redistribution, or modification of this software or any derived works
 * is strictly prohibited without prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
 */

/* Define our plugin name. */
if (!defined('FILE_ACTIVITY_PLUGIN')) {
	define('FILE_ACTIVITY_PLUGIN', 'file.activity');
}

/* Parse the plugin config file. */
$file_activity_cfg	= parse_plugin_cfg(FILE_ACTIVITY_PLUGIN, true);

$file_activity_log	= "/var/log/file.activity.log";
$zip				= str_replace(' ','_',strtolower($var['NAME']))."-file.activity-".date('Ymd-Hi').".zip";

/* monitored disks file. */
$disks_file			= "/tmp/".FILE_ACTIVITY_PLUGIN."/".FILE_ACTIVITY_PLUGIN.".disks";

/* Excluded shares file. */
$excluded_file		= "/tmp/".FILE_ACTIVITY_PLUGIN."/".FILE_ACTIVITY_PLUGIN.".exclude";

/* Detect Unraid version and assign a CSS class */
$unraid_version = '';
if (file_exists('/etc/unraid-version')) {
	$data = parse_ini_file('/etc/unraid-version');
	if ($data['version']) {
		$unraid_version = $data['version'];
	}
}

/* Default to legacy if not detected */
$title_class = 'legacy';

/* Compare version � 7.2 and newer = latest */
if (version_compare($unraid_version, '7.2', '>=')) {
	$title_class = 'latest';
}

$pidFile	= '/var/run/file.activity.pid';
$pidInotify	= '/var/run/file.activity.inotify.pid';
$pidLogging	= file_exists($pidInotify);
$pidRunning	= file_exists($pidFile);
$pidMain	= file_exists($pidFile);
$pidStatus	= $pidRunning ? 'Running' : 'Stopped';
$pidColor 	= $pidStatus == 'Running' ? 'green' : 'orange';

/* Default today_only. */
$today_only = (($_COOKIE['file_activity_today_only'] ?? '0') === '1') ? 1 : 0;

/* Default hide attributes. */
$hide_attrib = (($_COOKIE['file_activity_hide_attrib'] ?? '0') === '1') ? 1 : 0;

/* Default filter text. */
$filter_text = trim($_COOKIE['file_activity_filter'] ?? '');

/* Enable filtering? */
$filter_enabled = $pidRunning && $pidLogging;

/* Disks and pools and file. */
$disks_file	= '/tmp/file.activity/file.activity.disks';

/* Function to filter the log lines based on filter settings. */
function filter_log(array $log_lines, bool $today_only, bool $hide_attrib, string $filter_text): array {
	if ($today_only) {
		$today_month = date('M');
		$today_day = date('j');

		$log_lines = array_filter($log_lines, static function ($line) use ($today_month, $today_day) {
			return preg_match("/^{$today_month}\s+0?{$today_day}\b/", $line);
		});
	}

	if ($hide_attrib) {
		$log_lines = array_filter($log_lines, static function ($line) {
			return strpos($line, ' ATTRIB => ') === false;
		});
	}

	if ($filter_text !== '') {
		$terms = array_filter(array_map('trim', explode(',', $filter_text)));

		$use_mb = function_exists('mb_stripos');

		$log_lines = array_filter($log_lines, static function ($line) use ($terms, $use_mb) {
			foreach ($terms as $term) {
				$exclude = false;

				/* Leading ! means the term must NOT match */
				if (isset($term[0]) && $term[0] === '!') {
					$exclude = true;
					$term = substr($term, 1);
				}

				/* Ignore empty terms (e.g. "!,") */
				if ($term === '') {
					continue;
				}

				/* Determine whether the line matches the term */
				if (strpbrk($term, '*?') !== false) {
					$regex = '/.*' .
						str_replace(
							['\*', '\?'],
							['.*', '.'],
							preg_quote($term, '/')
						) .
						'.*/iu';

					$matched = (bool) preg_match($regex, $line);
				} else {
					$matched = $use_mb ? (mb_stripos($line, $term) !== false) : (stripos($line, $term) !== false);
				}

				/* Apply include/exclude logic */
				if ($exclude) {
					if ($matched) {
						return false;
					}
				} else {
					if (!$matched) {
						return false;
					}
				}
			}

			return true;
		});
	}

	return $log_lines;
}

$filter_help = implode("\n", [
	_("Enter one or more comma-separated search terms").".",
	_("All terms must match unless prefixed with '!'"),
	_("Use '!' to exclude matching entries."),
	_("Wildcards")." '*' "._("and")." '?' "._("are supported").".",
	_("Example").": MP3 Music".", write, *.mp3, !*.tmp"
]);
?>


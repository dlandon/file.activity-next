**File Activity - Next**

This plugin displays recent read, write, and modify file activity on array disks, pools, Unassigned Devices, and cache devices. It can help identify what is causing disks to spin up and provides powerful filtering options to quickly locate specific file activity.

The activity viewer supports filtering by multiple search terms, wildcard matching (* and ?), and exclusion filters using !, making it easy to isolate the events you're looking for.

Originally developed and maintained by Dan Landon.

Project repository, documentation, and license information are available on GitHub.
